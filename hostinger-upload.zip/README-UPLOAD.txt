DO NOT upload this folder as a zip manually.
Use the file hostinger-upload.zip from the project root.
That zip has package.json at the ROOT level (required by Hostinger).
